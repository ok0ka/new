import { Foundation } from './foundation.core';
import { Motion, Move } from '../../foundation.util.motion';

Foundation.Motion = Motion;
Foundation.Move = Move;
