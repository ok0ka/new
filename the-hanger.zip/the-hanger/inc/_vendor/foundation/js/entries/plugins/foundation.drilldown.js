import { Foundation } from './foundation.core';

import { Drilldown } from '../../foundation.drilldown';
Foundation.plugin(Drilldown, 'Drilldown');
