import { Foundation } from './foundation.core';

import { Interchange } from '../../foundation.interchange';
Foundation.plugin(Interchange, 'Interchange');
